import com.manydesigns.portofino.pageactions.login.DefaultLoginAction

class MyLogin extends DefaultLoginAction {

}