package com.manydesigns.portofino.pageactions.text

import com.manydesigns.portofino.security.*

@RequiresPermissions(level = AccessLevel.VIEW)
class MyTextAction extends com.manydesigns.portofino.pageactions.text.TextAction {

    //Automatically generated on Mon Sep 24 18:11:30 CEST 2018 by ManyDesigns Portofino
    //Write your code here

    @Override
    protected String computeTextFileName() {
        return super.computeTextFileName()
    }

}