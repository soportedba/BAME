import com.manydesigns.portofino.pageactions.text.*
import com.manydesigns.portofino.security.*

@RequiresPermissions(level = AccessLevel.VIEW)
class AngularJSExample extends TextAction {

}