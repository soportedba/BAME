package com.manydesigns.portofino.pageactions.text

import com.manydesigns.portofino.security.*

@RequiresPermissions(level = AccessLevel.VIEW)
class MyTextAction extends com.manydesigns.portofino.pageactions.text.TextAction {

    //Automatically generated on Sun Oct 07 15:35:15 UTC 2018 by ManyDesigns Portofino
    //Write your code here

    @Override
    protected String computeTextFileName() {
        return super.computeTextFileName()
    }

}