import com.manydesigns.portofino.security.*

import com.manydesigns.portofino.pageactions.chart.jfreechart.JFreeChartAction

@RequiresPermissions(level = AccessLevel.VIEW)
class MyChartAction extends JFreeChartAction {
    //Automatically generated on Wed Sep 19 13:27:44 CEST 2018 by ManyDesigns Portofino
    //Write your code here

}